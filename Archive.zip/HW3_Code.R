library(moderndive) 
library(tidyverse) 
library(jtools) 
library(interactions) 
library(GGally)
library(tidyverse)

# If you don’t have the libraries, you can install them with install.packages.
# We’ll work with a subset of data(diamonds) in library(tidyverse). 
# You can get information about the dataset with the command ?diamonds. 
# To get the subset in, please run the code below. Don’t use the full dataset.

set.seed(123)
data(diamonds)
diam = diamonds[sample(1:53940, 1000),]
summary(diam)
view(diam)
view(diamonds)

# Solve the following exercises.
# 1. Consider the following linear models for predicting the price of a diamond given carat:
# • price ~ carat
# • log(price) ~ carat
# • price ~ log(carat)
# • log(price) ~ log(carat)

model1 = lm(price ~ carat, data = diam)
model2 = lm(log(price) ~ carat, data = diam)
model3 = lm(price ~ log(carat), data = diam)
model4 = lm(log(price) ~ log(carat), data = diam)

# Use ggplot to visualize the models: put the outcome on the y-axis and the 
# predictor on the x-axis, and include a linear fit through the cloud of points. 
# Which linear model seems most adequate? Justify your answer.
ggplot(diam, aes(x = carat, y = price)) +
  geom_point() +
  geom_smooth(method = "lm")
ggplot(diam, aes(x = carat, y = log(price))) +
  geom_point() +
  geom_smooth(method = "lm")
ggplot(diam, aes(x = log(carat), y = price)) +
  geom_point() +
  geom_smooth(method = "lm")
ggplot(diam, aes(x = log(carat), y = log(price))) +
  geom_point() +
  geom_smooth(method = "lm")
# OUTPUT:
# It seems that the last model where we use log on both the price and carat variable 
# shows the most adequate fit throughout the plot b/c it seems more linear than the others
# and has more of an equality of variance. The two plot in the middle where price was
# transformed into a log or when carat was transformed into a log, shows a more skewed graph
# where the is a U curve going on in which shows the assumption of linearity is not satisfied.
# And the first graph seems to be more linear however there is not an equality of variance
# b/c the points seems to spread out more along as the xaxis get higher.

# 2. Use lm to fit the best model out of the four you looked at in the previous question. 
#    Interpret the coefficients. If your best model has transformations, interpret 
#    the coefficients both in the transformed and the original scales.

model4 = lm(log(price) ~ log(carat), data = diam)
summary(model4)
plot(model4)
# OUTPUT: interpretation of coefficients
# 1. Log scale transformation:
# log(carat): 1.67492
# If the log(price) of a diamond goes up by one unit then the model predicts
# that the log(carat) increases by 1.67492 units

# 2. Transforming back to original scales
# log y = b + m*x
# One unit increase in x
# is associated with a 
# 100*(exp(m)-1) percent change in y


# 3. Let’s add more variables to the model you chose in part 1. Do backward 
#    selection using AIC, starting with a model that includes the variable you 
#    chose in part 1. as well as x, y, z, and table. What is your final model? 
#    Do backward selection but with BIC. Do you select the same model? For the next 
#    questions, we’ll use the model you found with AIC.

install.packages("ISLR")
library(ISLR)
# n: sample size
# p: number of coefficients in model
# SSR: sum of squared residuals
# AIC = n*(log(2*pi*SSR/n)+1) + 2*(p+1)
# BIC = n*(log(2*pi*SSR/n)+1) + log(n)*(p+1)
n = nrow(diam)
# model4 = lm(log(price) ~ log(carat), data = diam)
#best model according to AIC doing backward selection
new_mod4 = lm(log(price) ~ log(carat)+x+y+z+table, data = diam)
summary(new_mod4)
back_AIC = step(new_mod4, direction = "backward")
summary(back_AIC)
# Variable z has been dropped using AIC backward selection.
# The algorithm will stop when dropping none is the best option
# dropping x,table, y, log(carat) would make my model worse
# lowest AIC is -2788.98,
# we get a model that predicts the log price given the log carat, x, y,& table
diam %>% count(carat)

-2788.98 < -2766.50

# different reasons to use different k's depending on your 
# you can put whatever penalty you want 
back_BIC = step(new_mod4, direction = "backward",k = log(n))
summary(back_BIC)
# lowest BIC is -2766.50,
# we get a model that predicts the log price given the log carat, y,& table

# Backward Selection AIC & BIC have different variables, with BIC showing that 
# only the predictors log carat, y, and table are the variables that actually affect the outcome.
# While AIC backward selection shows that the model that predicts log price given the variables
# log carat, x, y, and table are the best for the model prediction.

# AICs & BICs have good properties
# AIC is good for getting the best model for predictions
# BIC is best for identifying the variables that are actually affecting the outcome

# 4. Interpret the coefficients of the model you found in part 3. with AIC. 
#    If you transformed carat and / or price, interpret the coefficients both in 
#    the transformed scale and the original scale.

nontransformed_mod4 = lm(price ~ carat+x+y+z+table, data = diam)
n = nrow(diam)

back_AIC_nontrans = step(nontransformed_mod4, direction = "backward")
summary(back_AIC_nontrans)
# AIC = 14527.57, predictors: carat, x,y,z, and table.
#adjusted R2=0.8721
back_BIC_nontrans = step(nontransformed_mod4, direction = "backward",k = log(n))
summary(back_BIC_nontrans)
# BIC = 14557.02, predictors: carat, x,y,z, and table.
# adjusted R2=0.8721

# In question 3 I used transformations for my model which game me a negative model in 
# the backward AIC and BIC models, the use of only three predictor variables, and higher
# AIC-R2 of 0.9403 and BIC - R2 of 0.9401.
# However not transforming my model gave me a positive model with the both AIC and BIC models 
# containing the same variables: carat, x, y, z, and table. And having the same adjusted R2 of 0.8721 
# With the lowest model prediciton AIC of 14527.57 and BIC of 14557.02 showing  

# 5. Use plot to see if the LINE assumptions are satisfied for the model selected 
#    with AIC in part 3. Interpret the plots. Do you think that the assumptions 
#   of linearity, equality of variance, and normality are satisfied? Why or why not?
par(mfrow = c(2,2))
plot(new_mod4)

diam[704,]
# the outlier is this diamond that has 
# carat 1.01
# price 3167
# x = 6.66
# y = 6.6
# table = 59

new_mod4
plot(nontransformed_mod4)
#OUTPUT: explain q5
# The model with transformations shows more plots with variance of like in the plot 
# row 1 column 1 vs the nontransformed model which shows less of an equality of variance
# with the point more cluster around the zero point on the xaxis and spreads out more
# the further down the xaxis goes the more spread of variance there is.
# In both plots of Normal Q-Q and Residuals vs leverages we see the outlier points 704, 

# 6. Keep using the same model we’ve been using for the last few questions. 
#    Identify the diamonds with the highest absolute residuals, highest leverage, 
#    and highest Cook’s distance. Is there any reason that those observations have 
#    the highest values of those metrics? Explain why.

# So we can see normally from the graph a very high science score is associated 
# with a high reading score. But the outlier of the student that had a score of 
# 72 in science but a low score of a 42 in reading is weird, shows it has good 
# science and bad reading b/c its only score that shows both siFmultaneously, which
# makes it atypical.
# Cat values are especially intersting b/c they take into account multiple variables at once.
# Cooks distance: which quantifies how much my model fit 
# is affected by each observation

diam$absresidual = abs(residuals(new_mod4))
diam$leverage = hatvalues(new_mod4)
diam$cooks = cooks.distance(new_mod4)
view(diam)
?diamonds

# Highest Leverage
diam %>% slice_max(leverage, n = 3) 
summary(diam)

# A carat of 0.23 is minimum average of a diamond for carats and yet has a 
# table that has a maximum of 66, the x and y variable also has the minimum points of 
# 3.93 and 3.96, respectively
# which shows this diamond is atypical compared to the others.

# Highest Cooks 
diam %>% slice_max(cooks, n = 3) 
summary(diam)
# The outleir diamond that has a high cooks distance shows that the 3rd row, which shows
# that all categories of price,carat, x, and while are all within 3rd quantile and maximum range
# the table variable is atypical with a value of 56, which is in the 1st quantile.

# Highest residuals
diam %>% slice_max(absresidual, n = 3)
# Unfortunately, I do not see any of the high residuals on this output that 
# the plots in questions 4 shown. I think I may have made a mistake but I'm not sure
# at which point the mistake took place. The Residuals vs Leverage plot shows 
# an extreme outleir point of 704, which I did not find in my code to find the 
# highest residuals or highest leverage.
diam[704,]
# the outlier is this diamond that has 
# carat 1.01
# price 3167
# x = 6.66
# y = 6.6
# table = 59
# diamond 704 has a very large leverage
# which means that it has a weird combination
# of the variables
# this diamond sticks out so much is that it is
# an extreme value in 1 variable: table
